import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

import javax.swing.JSpinner.NumberEditor;



public class App {
    public static void main(String[] args) throws Exception {
        int numeros[] = new int[15];
        int numerosPares[] = new int[15];
        int numerosMais50[] = new int[15];
        Random random = new Random();

        // Entrada de dados
        for(int c1 = 0; c1 < numeros.length; c1++) {
            numeros[c1] = random.nextInt(0,100);
        }


        // Numeros Pares
        for(int c2 = 0; c2 < numeros.length; c2++) {
            if(numeros[c2] % 2 == 0) {
                numerosPares[c2] = numeros[c2];
            }
        }

        // Valor acima de 50
        for(int c3 = 0; c3 < numeros.length; c3++) {
            if(numeros[c3] > 50) {
                numerosMais50[c3] = numeros[c3];
            }
        }



        // Mostrar na ordem em que foi sorteado
        System.out.println("Números em ordem que foi sorteado.");
        for(int c4 = 0; c4 < numeros.length; c4++) {
            System.out.println(numeros[c4]);
        }
        System.out.println("============================");



        // Mostrar números em ordem crescente
        System.out.println("Números em ordem crescente");
        Arrays.sort(numeros);
        for(int c5 = 0; c5 < numeros.length; c5++) {
            System.out.println(numeros[c5]);
        }
        System.out.println("============================");




        // Mostrar numeros maiores que 50
        System.out.println("Números maiores que 50");
        for(int c6 = 0; c6 < numerosMais50.length; c6++) {
            System.out.println(numerosMais50[c6]);
        }
        System.out.println("============================");




        // Mostar números pares
        System.out.println("Números Pares");
        for(int c7 = 0; c7 < numerosPares.length; c7++) {
            System.out.println(numerosPares[c7]);
        }
    }
}