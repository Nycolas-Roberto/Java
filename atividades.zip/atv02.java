import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

import javax.swing.JSpinner.NumberEditor;



public class App {
    public static void main(String[] args) throws Exception {
        Scanner inAluno = new Scanner(System.in);
        Scanner inNota = new Scanner(System.in);

        String alunosNomes[][] = new String[5][3];
        int alunosMedia[][] = new int[5][3];

        int aprovados = 0;
        int acimaDaMedia = 0;


        // Entrada de dados
        for(int c1 = 1; c1 < alunosNomes.length; c1++) {
            System.out.println("Preencha o nome do " + c1 + "° Aluno: ");
            String nomeAluno = inAluno.nextLine();
            alunosNomes[c1] = nomeAluno;
            for(int c2 = 1; c2 <= 3; c2++) {
                System.out.println("Preencha a nota do " + c2 + " trimetre do aluno " + nomeAluno +":");
                int notaAluno = inNota.nextInt();
                alunosMedia[c2] = notaAluno;
            }
        }


        // Cálcular média
        for(int c3 = 0; c3 < alunosNomes.length; c3++) {
            int soma = 0;
            for(int c4 = 0; c4 < 3; c4++) {
                soma += alunosMedia[c3];
            }
            alunosMedia[c3] = soma / 3;
        }


        // Verificação de alunos aprovados e acima da média
        for(int c5 = 0; c5 < alunosNomes.length; c5++) {
            if(alunosMedia[c5] >= 7) {
                aprovados++;
            }
            int mediaTurma = 0;
            for(int c6 = 0; c6 < 5; c6++) {
                mediaTurma += alunosMedia[c6];
            }
            mediaTurma /= 5;
            if(alunosMedia[c5] > mediaTurma) {
                acimaDaMedia++;
            }
        }


        // Saída de dados
        System.out.println("Resultados abaixo");
        System.out.println("==========================");
        for(int c7 = 0; c7 < 5; c7++) {
            System.out.println("Aluno: " + alunosNomes[c7] + ", Média: " + alunosMedia[c7]);
            System.out.println("------------------");
        }
        System.out.println("==========================");
        System.out.println("Quantidade de alunos aprovados: " + aprovados);
        System.out.println("Quantidade de alunos acima da média: " + acimaDaMedia);
        inAluno.close();
        inNota.close();
    }
}
