import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

import javax.swing.JSpinner.NumberEditor;



public class App {
    public static void main(String[] args) throws Exception {
        int numeros[] = new int[50];
        for(int n = 0; n < numeros.length; n++) {
            numeros[n] = n + 101;
        }
        for(int numero : numeros) {
            System.out.println(numero);
        }
    }
}